# Instructor Demo Order

Recommended live sequence:

1. `ansible --version`
2. `ansible-inventory -i inventory.ini --graph`
3. `ansible webservers -i inventory.ini -m ansible.builtin.ping`
4. `ansible webservers -i inventory.ini -m ansible.builtin.command -a "uname -a"`
5. `ansible webservers -i inventory.ini -m ansible.builtin.shell -a "echo Hello && whoami"`
6. `ansible webservers -i inventory.ini -m ansible.builtin.file -a "path=/tmp/ansible-demo.txt state=touch"`
7. Run `02_first_playbook.yml`
8. Run `03_variables.yml`
9. Run `03_variables.yml` again and discuss `ok` vs `changed`
10. Run `04_role_demo.yml`
11. Open the Nginx page
12. Briefly show role structure and `ansible-galaxy init` (optional if time)
