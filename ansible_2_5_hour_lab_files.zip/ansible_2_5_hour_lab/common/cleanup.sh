#!/usr/bin/env bash
set -e

echo "Removing classroom-created files..."
rm -f /tmp/ansible-demo.txt
rm -f /tmp/ansible-first-playbook.txt
rm -f /tmp/ansible-variable-demo.txt

echo "Cleanup of temporary classroom files complete."
echo "Nginx was intentionally NOT removed."
