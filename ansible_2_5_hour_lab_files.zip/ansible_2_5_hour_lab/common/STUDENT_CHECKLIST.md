# Student Completion Checklist

Tick each item after you have successfully completed it.

- [ ] Ansible version displays correctly
- [ ] Inventory graph displays `webservers` and `development`
- [ ] `ansible ... -m ping` returns `pong`
- [ ] `command` module works
- [ ] `shell` module works
- [ ] `file` module creates/removes a file
- [ ] First playbook runs successfully
- [ ] Variable playbook runs successfully
- [ ] Running the variable playbook twice shows idempotent behavior (`ok` where nothing changed)
- [ ] Role playbook runs successfully
- [ ] Nginx is running
- [ ] Classroom HTML page opens in the browser
- [ ] You can explain: inventory, group, host, module, task, play, playbook, variable, role, idempotency
