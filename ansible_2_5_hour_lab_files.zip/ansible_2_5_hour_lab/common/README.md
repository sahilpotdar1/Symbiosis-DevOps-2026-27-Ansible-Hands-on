# Ansible 2.5-Hour Classroom Lab

## What this bundle demonstrates

1. Installation and verification
2. Inventory, hosts and groups
3. Ad-hoc commands
4. Modules
5. Command vs shell
6. Playbooks
7. Variables
8. Package installation
9. Service management
10. File copying/file management
11. Idempotency
12. Roles

## Design choice

The lab intentionally manages **localhost** rather than requiring every student to create a second VM/server. This makes the exercise practical on both macOS and Windows.

- macOS: Ansible runs directly on macOS.
- Windows: Ansible runs inside Ubuntu on WSL2. Windows itself is not used as the Ansible control node.

The role uses OS-specific tasks:
- Ubuntu/Debian -> apt + service + /var/www/html
- macOS -> Homebrew + Homebrew services + Homebrew nginx document root

This is deliberate: the concepts remain the same, but package/service management differs between operating systems.
