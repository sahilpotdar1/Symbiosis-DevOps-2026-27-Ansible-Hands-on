#!/usr/bin/env bash
# Run these commands in Terminal.

sw_vers
uname -m
python3 --version

# Check whether Homebrew already exists:
brew --version

# If brew is not found, install Homebrew using the official installer:
# /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
#
# IMPORTANT:
# After Homebrew installation, follow the shellenv command printed by the installer.
# Then close and reopen Terminal and run:
# brew --version
