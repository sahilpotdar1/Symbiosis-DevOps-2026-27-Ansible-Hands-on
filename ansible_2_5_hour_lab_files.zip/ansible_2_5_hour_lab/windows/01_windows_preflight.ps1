# Run this in PowerShell (preferably as Administrator for WSL installation checks).
# This file is informational: copy/paste commands one at a time.

wsl --status
wsl --version
wsl -l -v

# If WSL is not installed:
wsl --install

# If Ubuntu is not installed:
wsl --install -d Ubuntu

# If WSL installation appears stuck:
# wsl --install --web-download -d Ubuntu

# After installation/reboot, open "Ubuntu" from the Start menu.
# ALL ANSIBLE COMMANDS AFTER THIS POINT ARE RUN INSIDE THE UBUNTU TERMINAL,
# NOT in PowerShell.
